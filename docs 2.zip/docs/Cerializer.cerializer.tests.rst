Cerializer.cerializer.tests package
===================================

Submodules
----------

Cerializer.cerializer.tests.benchmark module
--------------------------------------------

.. automodule:: Cerializer.cerializer.tests.benchmark
   :members:
   :undoc-members:
   :show-inheritance:

Cerializer.cerializer.tests.dev\_utils module
---------------------------------------------

.. automodule:: Cerializer.cerializer.tests.dev_utils
   :members:
   :undoc-members:
   :show-inheritance:

Cerializer.cerializer.tests.test\_cerializer module
---------------------------------------------------

.. automodule:: Cerializer.cerializer.tests.test_cerializer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: Cerializer.cerializer.tests
   :members:
   :undoc-members:
   :show-inheritance:

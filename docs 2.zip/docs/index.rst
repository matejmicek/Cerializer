.. Cerializer documentation master file, created by
   sphinx-quickstart on Mon Mar 15 14:51:06 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Cerializer's documentation!
======================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   modules



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
